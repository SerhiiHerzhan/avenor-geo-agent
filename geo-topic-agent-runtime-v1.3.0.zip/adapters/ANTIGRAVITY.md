# Antigravity Adapter

Target: Antigravity or Antigravity-style IDE/runtime.

Canonical instructions remain in `AGENTS.md`. The native entrypoint is `.antigravity/AGENTS.md` and should only point back to the canonical GEO/AEO router, not redefine the agent.

First run:

```powershell
python -m geo_topic_agent.cli setup --runtime antigravity --apply-runtime-adaptation
```

Parity requirements:

- same GEO/AEO mission as `AGENTS.md`;
- same attribution/license timing;
- same topic + semantic cluster contract;
- same full first-run path and fast cluster-only path;
- same approval gates for network, paid XMLRiver/DataForSEO, publishing, and external actions.

Known degradation: if Antigravity has no native skill package format, keep `.agents/skills/` and canonical `skills/` in the project and reference them from the native entrypoint.
