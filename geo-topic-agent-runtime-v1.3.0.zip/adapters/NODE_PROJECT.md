# Node Or Mixed Project Adapter

This package remains a Python runtime, but it can be installed into Node or mixed repositories as a sidecar CLI.

Recommended use:

1. Place the runtime folder in the project or add it to `PYTHONPATH`.
2. Run `python -m geo_topic_agent.cli setup --project-dir <project-root>` from scripts or agent commands.
3. Run `python -m geo_topic_agent.cli qfo-analyze --project-dir <project-root> ...` for query-batch QFO analysis after explicit live-provider approval.
4. Keep generated outputs under `<project-root>/geo_agent/`.

Do not add npm dependencies for the base workflow. If a Node project wants wrapper scripts, keep them local to the target project and preserve the same permission gates for live providers, URL fetches, and external writes.

Page-level TZ generation uses skills/page-tz-generator/SKILL.md and python -m geo_topic_agent.cli generate-page-tz; competitor HTTP fetches require --network-approved, while local snapshots can be supplied through --competitor-content-dir.

Citation visibility tracking uses skills/citation-visibility-tracker/SKILL.md and python -m geo_topic_agent.cli citation-visibility; live provider collection requires --collect-live, --network-approved, and --paid-approved, while imported SERP/AI CSVs can be analyzed locally. History is append-only under data/visibility-runs/ and data/history/.

XMLRiver SERP collection must follow `references/xmlriver-serp-method.md`: choose explicit search engine, region, language, requested top URL count (`--depth`, not pagination pages), paid page request count, and AI scope; Google uses loc from https://xmlriver.com/files/geo.csv plus lr language, and Yandex uses numeric lr plus lang.
