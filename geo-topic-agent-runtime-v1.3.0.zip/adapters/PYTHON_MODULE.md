# Python Module Adapter

The runtime can be used as a Python module or CLI from Python, Node, mixed, or shell-driven projects.

CLI entrypoint:

```powershell
python -m geo_topic_agent.cli <command>
```

Python entrypoints are defined in `geo_topic_agent.core` and `geo_topic_agent.qfo_analysis`, including:

- `setup_environment`
- `init_project_context`
- `audit_accessibility`
- `llm_accessibility_audit`
- `provider_audit`
- `collect_serp`
- `qfo_query_analysis` from `geo_topic_agent.qfo_analysis`
- `generate_page_tz` from `geo_topic_agent.tz_page_generator`
- `run_topic_workflow`
- `generate_tz_handoff`
- `invoke_tz_generator`
- `find_placements`
- `enrich_urls`
- `monitor_plan`
- `completion_audit`

Every function returns a structured observation with `status`, `summary`, `items`, `evidence_refs`, and `next_valid_actions`.

Page-level TZ generation uses skills/page-tz-generator/SKILL.md and python -m geo_topic_agent.cli generate-page-tz; competitor HTTP fetches require --network-approved, while local snapshots can be supplied through --competitor-content-dir.

Citation visibility tracking uses skills/citation-visibility-tracker/SKILL.md and python -m geo_topic_agent.cli citation-visibility; live provider collection requires --collect-live, --network-approved, and --paid-approved, while imported SERP/AI CSVs can be analyzed locally. History is append-only under data/visibility-runs/ and data/history/.

XMLRiver SERP collection must follow `references/xmlriver-serp-method.md`: choose explicit search engine, region, language, requested top URL count (`--depth`, not pagination pages), paid page request count, and AI scope; Google uses loc from https://xmlriver.com/files/geo.csv plus lr language, and Yandex uses numeric lr plus lang.
