# Generic Agent Adapter

Target: any agent IDE/runtime that can read a root instruction file and run local Python commands.

Canonical instructions remain in `AGENTS.md`. The generic native entrypoint is `AGENT.md`.

First run:

```powershell
python -m geo_topic_agent.cli setup --runtime generic --apply-runtime-adaptation
```

If the runtime has its own instruction filename, copy or link `AGENT.md` to that filename only after explicit user approval. Do not silently merge or rewrite native instruction files.

Parity requirements:

- environment adaptation before project adaptation;
- deep project/brand context before audit;
- audit before topic/cluster intake unless the audit is explicitly declined;
- topic work uses confirmed `topic + semantic_cluster_queries`;
- quick/fast run asks only for cluster when saved project context already exists.
