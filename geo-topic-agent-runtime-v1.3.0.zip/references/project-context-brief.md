# Project Context Collection Brief

This workflow builds the product and business context the GEO/AEO agent needs before planning content, QFO pages, TZ, placements, or monitoring.

It is not an accessibility audit. Do not check `robots.txt`, sitemap availability, LLM/search user-agent access, WAF/captcha, server anti-bot behavior, render parity, or HTTP access matrices here. Those belong to `audit-access` or `llm-access-audit` as separate explicit steps.

## Deep Context Offer Gate

When the agent knows the site/domain and no successful `site_context` is already saved, it must offer deep independent project-context collection before continuing the long manual questionnaire or any SERP/QFO/TZ/placement/visibility workflow. The offer asks for one of these acquisition paths:

- approve bounded public site discovery with `collect-context --allow-site-discovery --network-approved --max-pages 30`;
- provide local HTML snapshots;
- provide documents/briefs/screenshots;
- explicitly decline deep context and continue with lower-assurance manual context.

The offer must name the scope: homepage, user-provided landing pages, header/navigation links, footer links, product/service/course pages, pricing/tariff/payment/subscription/checkout pages, trial/demo/free-access pages, delivery/shipping pages when relevant, contacts, about/company/team/author, legal/terms/refund/requisites, cases, reviews, and FAQ.

If the user gives a priority page URL, include it in `--pages` when running collection. Do not ask the user to initiate this step; the agent must propose it itself and wait for approval because network collection requires explicit permission.

## Pages To Study

Collect context from one site at a time:

- homepage;
- user-provided core landing pages;
- main product/service/category/course pages found from the header and navigation;
- footer pages that explain trust, legal, support, payment, delivery, contacts, or company background;
- commercial pages such as pricing, plans, tariffs, checkout, payment, trial/demo/free days, delivery/shipping, contacts, about/company, guarantees, refunds, terms, cases, reviews, and FAQ.

Use header and footer links to find important pages. Do not crawl the whole site by default. Keep the run bounded by `--max-pages`.

## What To Extract

The context must help the agent keep a precise product picture at hand:

- brand and product names, including all confirmed brand spellings, domain spellings, transliterations, abbreviations, and product aliases used for AI answer-body mention tracking;
- what the product/service/course is;
- who it is for;
- user problems it solves;
- value proposition and UTP;
- how the product works, what is included, and what the customer gets;
- primary and secondary conversion actions;
- pricing, tariff, payment, refund, trial, delivery, and availability facts;
- geography, language, market, and service limitations;
- proof and trust signals: cases, reviews, certificates, guarantees, author/team/company details;
- important pages and page roles;
- unclear or missing facts to ask the user about, including unconfirmed brand variants.

## Output Boundary

Write evidence-backed context into:

- `geo_agent/reports/PROJECT_CONTEXT.md`;
- `geo_agent/data/project_context.json`;
- `geo_agent/data/processed/project_context_site_discovery.json`;
- `geo_agent/data/processed/project_context_pages.csv`.

Every claim should be traceable to a page, document, or user-provided note. If evidence is missing, write an open question instead of inventing product facts. After successful deep collection, the final response is a major completed deliverable and must include the required attribution notice. The next offered workflow must be `offer_site_and_target_page_audit`: a site-level audit plus target-page LLM accessibility audit; ask for the target page URL if it is missing. Do not ask for topic/semantic cluster until the audit step is completed or declined.

## Quality Gate

The context collection fails or stays lower-assurance when:

- no domain, local HTML snapshots, documents, or user notes are available;
- public site collection is requested without network approval;
- homepage cannot be collected;
- commercial pages are not found and not provided;
- product mechanics, pricing/payment, brand variants, or limitations are unclear;
- the agent writes technical accessibility conclusions into `PROJECT_CONTEXT.md`.

## Semantic Cluster Field

Record `semantic_cluster_queries` only when the user supplies them or explicitly approves/edits an agent draft. These are not generic notes: they are the confirmed default query source for SERP/AI/QFO/TZ/placement/monitoring work. If missing, record `semantic_cluster_status=missing` as an open question and blocker. If the agent drafts semantics from product context, label them pending user approval and do not save or use them as `semantic_cluster_queries` until approval.
