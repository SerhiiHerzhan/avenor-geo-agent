# QFO Query Analysis Method

QFO means Query Fan-Out. In this runtime it is the evidence-backed expansion of a user's seed query batch into likely follow-up, adjacent, implied, and reformulated searches that AI/search systems may use around a topic.

The QFO analysis exists to answer four practical questions:

1. What did the user explicitly ask us to investigate?
2. Which of those queries returned AI-answer blocks in live XMLRiver SERP data?
3. Which cited page titles appear in AI-answer source evidence and what user problems/page jobs do they imply?
4. Which content pages should be created as hubs or child pages after agent/subagent logical clustering, without cannibalizing each other?

## Live Evidence Rule

For production QFO analysis, XMLRiver must be called with `ai=1` for every user-provided seed query and selected engine. By default, `qfo-analyze` uses both `google,yandex`; if a narrower run is needed, the user must explicitly pass `--engines`. Before any live request, read `references/xmlriver-serp-method.md` and set explicit search engine, region, language, requested top URL count (`--depth`, not pagination pages), paid-request scope, and XMLRiver max thread scope (`XMLRIVER_MAX_THREADS=10`). The command is blocked unless both gates are present:

```powershell
python -m geo_topic_agent.cli qfo-analyze --queries "<query batch>" --engines "google,yandex" --depth <top-url-count> --network-approved --paid-approved
```

The runtime saves raw XML and parsed CSV/JSON artifacts. If an AI answer block is absent for a query, the query is still recorded; absence is evidence, not a reason to invent AI rows.

## Title Extraction

AI-cited titles are extracted from XMLRiver AI source rows. If the source row has a cited URL but no title, the runtime tries to match the URL to the organic rows collected in the same run. Titles without a cited URL are allowed only when the AI block provides a title-like source label.

## Title Semantics Inventory

Each AI-cited page title is already the semantic evidence unit. The runtime must not expand titles into additional search queries with templates, masks, n-grams, or intent permutations.

The title inventory is the source material for agent reasoning. Preserve the full list of titles, source queries, cited URLs, domains, and raw references so the content planner can understand what pages are actually visible in AI answers.

## Clustering And Cannibalization

Clustering is logical and conservative. The deterministic runtime only prepares the full title inventory and exact-title evidence counts. The agent or a clean subagent must read the entire title list and group titles by user problem, buying stage, page job, and cannibalization risk. A hub is proposed when the logical cluster is broad and recurring. A child page is proposed only when the page job is materially distinct enough to deserve its own URL.

Cannibalization guard:

- do not split pages only by word order or synonym;
- keep one hub for broad informational coverage;
- create child pages for separate jobs such as price, comparison, implementation, reviews, or a specific audience;
- mark weak themes as merge candidates until the user approves them.

## ChatGPT QFO Layer

After XMLRiver evidence is processed, the agent asks the user to provide a ChatGPT QFO export. This is optional. If the user skips it, the report must say that the ChatGPT layer is pending/skipped and continue with XMLRiver evidence.

## Content Plan

The content plan must show:

- page type: hub or child;
- target logical cluster;
- included AI-cited titles plus source queries;
- evidence counts;
- suggested title/URL slug;
- internal linking relationship;
- cannibalization warning;
- status: `pending_user_filter` or `accepted_by_user`.
