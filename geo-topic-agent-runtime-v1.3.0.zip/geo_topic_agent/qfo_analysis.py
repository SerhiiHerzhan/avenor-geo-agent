from __future__ import annotations

import html
import re
import urllib.parse
from collections import defaultdict
from pathlib import Path
from typing import Any

from .core import (
    IMPORT_REL,
    PROCESSED_REL,
    RAW_REL,
    REPORTS_REL,
    XMLRIVER_ENDPOINTS,
    XMLRIVER_MAX_THREADS,
    collect_xmlriver_plan_parallel,
    ensure_dirs,
    escape_md,
    external_approval_ledger_path,
    find_project_root,
    load_env_values,
    load_external_approval_records,
    normalize_domain,
    normalize_ws,
    observation,
    portable_ref,
    read_csv,
    read_json,
    repair_text_encoding,
    sha12,
    slugify,
    split_csv,
    update_state,
    utc_now,
    write_csv,
    write_json,
    write_text,
    xmlriver_accounts,
    validate_serp_top_url_depth,
    xmlriver_paid_request_count,
    xmlriver_serp_page_count,
    xmlriver_thread_scope,
    XMLRIVER_SERP_URLS_PER_PAGE,
)


def qfo_split_input_text(value: str) -> list[str]:
    if not value:
        return []
    value = repair_text_encoding(value)
    normalized = value.replace(";", "\n")
    if "\n" not in normalized and "," in normalized:
        normalized = normalized.replace(",", "\n")
    rows = []
    for line in normalized.splitlines():
        cleaned = normalize_ws(line.strip().strip("-*").strip())
        if cleaned:
            rows.append(cleaned)
    return rows


def load_qfo_seed_queries(queries: str = "", queries_file: str = "") -> list[dict[str, Any]]:
    values: list[tuple[str, str]] = []
    if queries_file:
        path = Path(queries_file)
        if path.exists():
            suffix = path.suffix.lower()
            if suffix == ".csv":
                for row in read_csv(path):
                    query = row.get("query") or row.get("seed_query") or row.get("keyword") or next((v for v in row.values() if v), "")
                    if query:
                        values.append((normalize_ws(repair_text_encoding(str(query))), str(path)))
            elif suffix == ".json":
                payload = read_json(path, [])
                items = payload.get("queries", []) if isinstance(payload, dict) else payload
                if isinstance(items, list):
                    for item in items:
                        query = item.get("query", "") if isinstance(item, dict) else str(item)
                        if query:
                            values.append((normalize_ws(repair_text_encoding(query)), str(path)))
            else:
                for query in qfo_split_input_text(path.read_text(encoding="utf-8-sig")):
                    values.append((query, str(path)))
    for query in qfo_split_input_text(queries):
        values.append((query, "inline"))

    rows = []
    for idx, (query, source_ref) in enumerate(values, start=1):
        rows.append({
            "query_id": f"qfo_seed_{idx:04d}",
            "source_order": idx,
            "query": query,
            "source_ref": source_ref,
            "status": "pending_live_xmlriver",
        })
    return rows


def load_qfo_chatgpt_queries(chatgpt_qfo_file: str = "") -> list[dict[str, Any]]:
    if not chatgpt_qfo_file:
        return []
    path = Path(chatgpt_qfo_file)
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    suffix = path.suffix.lower()
    if suffix == ".csv":
        for idx, row in enumerate(read_csv(path), start=1):
            query = row.get("query") or row.get("qfo_query") or row.get("prompt") or row.get("keyword") or next((v for v in row.values() if v), "")
            if query:
                rows.append({"chatgpt_qfo_id": f"chatgpt_qfo_{idx:04d}", "query": normalize_ws(str(query)), "source_ref": str(path)})
    elif suffix == ".json":
        payload = read_json(path, [])
        items = payload.get("queries", []) if isinstance(payload, dict) else payload
        if isinstance(items, list):
            for idx, item in enumerate(items, start=1):
                query = item.get("query", "") if isinstance(item, dict) else str(item)
                if query:
                    rows.append({"chatgpt_qfo_id": f"chatgpt_qfo_{idx:04d}", "query": normalize_ws(query), "source_ref": str(path)})
    else:
        for idx, query in enumerate(qfo_split_input_text(path.read_text(encoding="utf-8-sig")), start=1):
            rows.append({"chatgpt_qfo_id": f"chatgpt_qfo_{idx:04d}", "query": query, "source_ref": str(path)})
    return rows


def qfo_url_key(value: str) -> str:
    if not value:
        return ""
    parsed = urllib.parse.urlsplit(value)
    host = parsed.netloc.lower().removeprefix("www.")
    path = re.sub(r"/+$", "", parsed.path.lower())
    return f"{host}{path}"


def qfo_title_from_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    parts = [part for part in parsed.path.split("/") if part]
    if parts:
        return normalize_ws(re.sub(r"[-_]+", " ", urllib.parse.unquote(parts[-1]))).title()
    return normalize_domain(url) or url


def qfo_base_title(title: str) -> str:
    cleaned = html.unescape(normalize_ws(title))
    cleaned = re.sub(r"\.?\s+Opens? in (a )?new tab\.?$", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.split(r"\s+[|]\s+|\s+-\s+|\s+::\s+", cleaned, maxsplit=1)[0]
    return cleaned[:180].strip() or title[:180].strip()


def extract_qfo_ai_titles(ai_rows: list[dict[str, Any]], serp_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    organic_titles = {}
    for row in serp_rows:
        key = qfo_url_key(str(row.get("url", "")))
        if key and row.get("title") and key not in organic_titles:
            organic_titles[key] = row.get("title")
    rows = []
    for idx, row in enumerate(ai_rows, start=1):
        url = str(row.get("citation_url", ""))
        title = normalize_ws(str(row.get("citation_title", "")))
        title_source = "ai_source_title" if title else ""
        if not title and url:
            title = normalize_ws(str(organic_titles.get(qfo_url_key(url), "")))
            title_source = "organic_url_match" if title else ""
        if not title and url:
            title = qfo_title_from_url(url)
            title_source = "url_fallback"
        if not title:
            continue
        rows.append({
            "title_id": f"qfo_title_{idx:04d}",
            "source_query": row.get("prompt", ""),
            "provider": row.get("provider", "xmlriver"),
            "model": row.get("model", ""),
            "citation_url": url,
            "citation_domain": normalize_domain(url),
            "citation_title": title,
            "base_title": qfo_base_title(title),
            "title_source": title_source or "unknown",
            "answer_id": row.get("answer_id", ""),
            "answer_text_present": bool(row.get("answer_text")),
            "raw_ref": row.get("raw_ref", ""),
        })
    return rows


def qfo_exact_title_key(value: str) -> str:
    base = qfo_base_title(value).casefold()
    return "title:" + sha12(base or value.casefold())


def qfo_title_semantic_units(ai_titles: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Treat each AI-cited page title as the semantic unit. No query/template expansion."""
    rows: list[dict[str, Any]] = []
    for idx, title_row in enumerate(ai_titles, start=1):
        semantic_title = qfo_base_title(str(title_row.get("base_title") or title_row.get("citation_title") or ""))
        if not semantic_title:
            continue
        rows.append({
            "semantic_unit_id": f"qfo_title_semantic_{idx:04d}",
            "source_type": "ai_cited_title",
            "source_query": title_row.get("source_query", ""),
            "source_title_id": title_row.get("title_id", ""),
            "source_title": title_row.get("citation_title", ""),
            "semantic_title": semantic_title,
            "citation_url": title_row.get("citation_url", ""),
            "citation_domain": title_row.get("citation_domain", ""),
            "title_source": title_row.get("title_source", ""),
            "answer_id": title_row.get("answer_id", ""),
            "raw_ref": title_row.get("raw_ref", ""),
            "theme_key": qfo_exact_title_key(semantic_title),
            "cluster_basis": "exact_ai_cited_title_pending_agent_logic",
            "agent_cluster_status": "pending_logical_clustering",
        })
    return rows

def qfo_parse_selected_themes(selected_themes: str) -> set[str]:
    return {item.casefold() for item in qfo_split_input_text(selected_themes) if item.strip()}


def qfo_cluster_queries(
    title_semantic_rows: list[dict[str, Any]],
    ai_titles: list[dict[str, Any]],
    seed_rows: list[dict[str, Any]],
    chatgpt_rows: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Prepare an agent workpack from AI-cited titles without mechanical query expansion.

    The function only deduplicates exact titles for evidence counting. Real semantic
    clustering is intentionally left to the agent or a clean subagent that reads the
    full title list and reasons about user problems, page jobs, and cannibalization.
    """
    if not title_semantic_rows:
        return [], []

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in title_semantic_rows:
        grouped[row.get("theme_key") or qfo_exact_title_key(row.get("semantic_title", ""))].append(row)

    theme_rows: list[dict[str, Any]] = []
    for idx, (theme_key, rows) in enumerate(sorted(grouped.items(), key=lambda item: (qfo_base_title(item[1][0].get("semantic_title", "")).casefold(), item[0])), start=1):
        semantic_titles = []
        source_queries = []
        citation_urls = []
        citation_domains = []
        raw_refs = []
        for row in rows:
            for value, target in [
                (row.get("semantic_title", ""), semantic_titles),
                (row.get("source_query", ""), source_queries),
                (row.get("citation_url", ""), citation_urls),
                (row.get("citation_domain", ""), citation_domains),
                (row.get("raw_ref", ""), raw_refs),
            ]:
                value = normalize_ws(str(value or ""))
                if value and value not in target:
                    target.append(value)
        label = semantic_titles[0] if semantic_titles else theme_key.replace("title:", "")
        theme_rows.append({
            "theme_id": f"qfo_theme_{idx:03d}",
            "theme_key": theme_key,
            "theme_label": qfo_base_title(label),
            "cluster_mode": "agent_or_clean_subagent_logical_clustering_required",
            "system_requested_count": len(rows),
            "chatgpt_qfo_count": 0,
            "title_semantic_count": len(rows),
            "source_seed_query_count": len(source_queries),
            "ai_title_count": len(rows),
            "ai_citation_count": len(citation_urls),
            "citation_domain_count": len(citation_domains),
            "dominant_intents": "agent_to_determine_from_full_title_list",
            "evidence_title_list": " | ".join(semantic_titles),
            "source_seed_queries": " | ".join(source_queries),
            "citation_domains": " | ".join(citation_domains),
            "raw_refs": " | ".join(raw_refs[:12]),
            "recommended_structure": "pending_agent_logical_cluster",
            "recommended_action": "Agent or clean subagent must read the full AI title list and group titles by user problem/page job before creating hub or child pages.",
            "cannibalization_guard": "Do not create a page from an exact title row alone. Merge titles that solve the same user task; split only when the page job is materially different.",
            "content_plan_status": "pending_agent_review",
        })
    return theme_rows, title_semantic_rows


def qfo_build_content_plan(
    theme_rows: list[dict[str, Any]],
    title_semantic_rows: list[dict[str, Any]],
    selected_themes: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    selected = qfo_parse_selected_themes(selected_themes)
    selection_active = bool(selected)
    selected_rows: list[dict[str, Any]] = []
    for row in theme_rows:
        keys = {
            str(row.get("theme_id", "")).casefold(),
            str(row.get("theme_key", "")).casefold(),
            str(row.get("theme_label", "")).casefold(),
        }
        is_selected = not selection_active or bool(keys & selected)
        selection_row = dict(row)
        selection_row["selected"] = "yes" if is_selected and selection_active else ""
        selected_rows.append(selection_row)

    rows_by_theme: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in title_semantic_rows:
        rows_by_theme[row.get("theme_key", "")].append(row)

    plan_rows: list[dict[str, Any]] = []
    page_index = 0
    for theme in selected_rows:
        if selection_active and theme.get("selected") != "yes":
            continue
        title_rows = rows_by_theme.get(theme.get("theme_key", ""), [])
        source_queries = []
        semantic_titles = []
        citation_urls = []
        for row in title_rows:
            for value, target in [
                (row.get("source_query", ""), source_queries),
                (row.get("semantic_title", ""), semantic_titles),
                (row.get("citation_url", ""), citation_urls),
            ]:
                value = normalize_ws(str(value or ""))
                if value and value not in target:
                    target.append(value)
        page_index += 1
        candidate_slug = slugify(theme.get("theme_label", theme.get("theme_key", "qfo-title")))
        plan_rows.append({
            "page_id": f"qfo_page_{page_index:03d}",
            "theme_id": theme.get("theme_id", ""),
            "page_type": "agent_cluster_candidate",
            "intent": "agent_to_define_from_full_title_list",
            "target_title": theme.get("theme_label", ""),
            "suggested_url": f"/{candidate_slug}/",
            "included_queries": " | ".join(source_queries[:20]),
            "included_titles": " | ".join(semantic_titles),
            "citation_urls": " | ".join(citation_urls[:20]),
            "system_requested_count": theme.get("system_requested_count", 0),
            "chatgpt_qfo_count": theme.get("chatgpt_qfo_count", 0),
            "evidence_counts": f"title_semantics={theme.get('title_semantic_count', 0)}; ai_citations={theme.get('ai_citation_count', 0)}; source_queries={theme.get('source_seed_query_count', 0)}",
            "content_plan_basis": "AI-cited page titles are the semantic units; no template or mask expansion was used.",
            "internal_linking": "Define only after the agent groups titles into hub/child page jobs.",
            "cannibalization_guard": theme.get("cannibalization_guard", ""),
            "status": "selected_pending_agent_logical_plan" if selection_active else "pending_agent_logical_plan",
        })
    return plan_rows, selected_rows


def qfo_summary_payload(
    status: str,
    topic: str,
    seed_rows: list[dict[str, Any]],
    chatgpt_rows: list[dict[str, Any]],
    plan_rows: list[dict[str, Any]],
    serp_rows: list[dict[str, Any]],
    ai_rows: list[dict[str, Any]],
    ai_titles: list[dict[str, Any]],
    title_semantic_rows: list[dict[str, Any]],
    theme_rows: list[dict[str, Any]],
    content_plan: list[dict[str, Any]],
    selected_rows: list[dict[str, Any]],
    paths: dict[str, str],
    errors: list[str],
    network_approved: bool,
    paid_approved: bool,
    engines: list[str],
    region: str,
    language: str,
    depth: int,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = {
        "status": status,
        "topic": topic,
        "network_approved": network_approved,
        "paid_approved": paid_approved,
        "engines": engines,
        "region": region,
        "language": language,
        "depth": depth,
        "requested_top_urls": depth,
        "depth_semantics": "--depth is the requested organic URL count/top-N, not a pagination page count",
        "xmlriver_results_per_page": XMLRIVER_SERP_URLS_PER_PAGE,
        "xmlriver_serp_pages_per_query_engine": xmlriver_serp_page_count(depth),
        "planned_query_engine_pairs": len(plan_rows),
        "planned_requests": xmlriver_paid_request_count(len(plan_rows), depth),
        "planned_paid_requests": xmlriver_paid_request_count(len(plan_rows), depth),
        **xmlriver_thread_scope(xmlriver_paid_request_count(len(plan_rows), depth)),
        "seed_query_count": len(seed_rows),
        "chatgpt_qfo_count": len(chatgpt_rows),
        "serp_rows_count": len(serp_rows),
        "ai_answer_rows_count": len(ai_rows),
        "ai_titles_count": len(ai_titles),
        "title_semantic_unit_count": len(title_semantic_rows),
        "template_query_generation_from_titles": "disabled",
        "theme_clusters_count": len(theme_rows),
        "content_plan_rows_count": len(content_plan),
        "seed_query_values": [row.get("query", "") for row in seed_rows],
        "seed_query_rows": seed_rows,
        "chatgpt_qfo_rows": chatgpt_rows,
        "ai_title_rows": ai_titles,
        "title_semantic_rows": title_semantic_rows,
        "clusters": theme_rows,
        "content_plan": content_plan,
        "selected_theme_rows": selected_rows,
        "paths": paths,
        "errors": errors,
        "generated_at": utc_now(),
    }
    if extra:
        payload.update(extra)
    return payload

def record_qfo_xmlriver_approval(
    root: Path,
    topic: str,
    topic_slug: str,
    engines: list[str],
    query_count: int,
    depth: int,
    region: str,
    language: str,
) -> Path:
    path = external_approval_ledger_path(root)
    _, records = load_external_approval_records(root)
    record = {
        "evidence_id": "qfo_xmlriver_live_run",
        "status": "approved",
        "approved_by": "user",
        "approval_ref": "cli_flags:--network-approved --paid-approved",
        "approved_at": utc_now(),
        "topic_slug": topic_slug,
        "scope": {
            "provider": "xmlriver",
            "engines": engines,
            "query_count": query_count,
            "depth": depth,
            "region": region,
            "language": language,
            "topic": topic,
            "maximum_request_count": query_count * max(1, len(engines)),
        },
        "budget": {
            "paid_approved": True,
            "limit_type": "request_count",
            "maximum_request_count": query_count * max(1, len(engines)),
        },
    }
    pages_per_pair = xmlriver_serp_page_count(depth)
    paid_request_count = xmlriver_paid_request_count(query_count * max(1, len(engines)), depth)
    record["scope"].update({
        "requested_top_urls": depth,
        "depth_semantics": "--depth is the requested organic URL count/top-N, not a pagination page count",
        "xmlriver_results_per_page": XMLRIVER_SERP_URLS_PER_PAGE,
        "serp_pages_per_query_engine": pages_per_pair,
        "query_engine_pairs": query_count * max(1, len(engines)),
        "maximum_request_count": paid_request_count,
        **xmlriver_thread_scope(paid_request_count),
    })
    record["budget"].update({"maximum_request_count": paid_request_count, **xmlriver_thread_scope(paid_request_count)})
    records.append(record)
    write_json(path, {"approvals": records})
    return path


def build_qfo_chatgpt_request_report(topic: str, seed_rows: list[dict[str, Any]], chatgpt_rows: list[dict[str, Any]]) -> str:
    status = "provided" if chatgpt_rows else "optional_pending"
    sample_queries = [row.get("query", "") for row in seed_rows[:10]]
    lines = [
        "# QFO_CHATGPT_REQUEST",
        "",
        f"Generated: {utc_now()}",
        f"Topic: {topic}",
        f"Status: {status}",
        "",
        "## What To Provide",
        "",
        "Paste or save the QFO/query fan-out suggestions you collected from ChatGPT. This layer is optional; the XMLRiver AI-title semantic inventory continues without it.",
        "",
        "Suggested file formats:",
        "",
        "- TXT: one query per line",
        "- CSV: a `query` or `qfo_query` column",
        "- JSON: a list of strings or `{\"queries\": [...]}`",
        "",
        "## Prompt Template",
        "",
        "```text",
        "For the topic below, produce QFO/query fan-out suggestions. Include adjacent commercial, comparison, how-to, price, review, and problem/solution searches. Return one query per line.",
        f"Topic: {topic}",
        "Seed queries:",
    ]
    lines.extend(sample_queries or ["<paste seed queries here>"])
    lines.extend(["```", "", "If the user skips this step, keep the content plan based on XMLRiver evidence and mark ChatGPT QFO as pending/skipped."])
    return "\n".join(lines) + "\n"



def build_qfo_query_analysis_report(
    topic: str,
    seed_rows: list[dict[str, Any]],
    plan_rows: list[dict[str, Any]],
    serp_rows: list[dict[str, Any]],
    ai_rows: list[dict[str, Any]],
    ai_titles: list[dict[str, Any]],
    title_semantic_rows: list[dict[str, Any]],
    theme_rows: list[dict[str, Any]],
    content_plan: list[dict[str, Any]],
    chatgpt_rows: list[dict[str, Any]],
    errors: list[str],
    status: str,
    paths: dict[str, str],
) -> str:
    lines = [
        "# QFO_QUERY_ANALYSIS",
        "",
        f"Generated: {utc_now()}",
        f"Topic: {topic}",
        f"Status: {status}",
        "",
        "## What QFO Means",
        "",
        "QFO means Query Fan-Out: follow-up, adjacent, implied, and reformulated searches that can appear around the user's seed queries. In this runtime the semantic source for QFO planning is the AI-cited page title inventory, not mechanically generated title variants.",
        "",
        "## Scope And Counts",
        "",
        f"- Seed queries supplied: {len(seed_rows)}",
        f"- XMLRiver query x engine pairs: {len(plan_rows)}",
        f"- Requested top URLs per pair (`--depth`): {plan_rows[0].get('requested_top_urls', 'not set') if plan_rows else 'not set'}",
        f"- XMLRiver SERP pages per pair: {plan_rows[0].get('xmlriver_serp_pages_per_query_engine', 'not set') if plan_rows else 'not set'}",
        f"- XMLRiver planned paid page requests: {sum(int(row.get('planned_paid_requests', 1)) for row in plan_rows)}",
        f"- XMLRiver max live threads: {XMLRIVER_MAX_THREADS}",
        f"- XMLRiver planned thread slots: {xmlriver_thread_scope(sum(int(row.get('planned_paid_requests', 1)) for row in plan_rows)).get('xmlriver_thread_slots_planned') if plan_rows else 0}",
        f"- Organic SERP rows parsed: {len(serp_rows)}",
        f"- AI answer/source rows parsed: {len(ai_rows)}",
        f"- AI-cited titles extracted: {len(ai_titles)}",
        f"- Title semantic units: {len(title_semantic_rows)}",
        "- Template/mask query generation from titles: disabled",
        f"- Optional ChatGPT QFO rows: {len(chatgpt_rows)}",
        f"- Exact-title evidence rows for agent clustering: {len(theme_rows)}",
        f"- Content plan candidate rows: {len(content_plan)}",
        "",
        "## Evidence Basis",
        "",
    ]
    if not ai_titles:
        lines.extend([
            "- No AI-cited titles are available yet. The runtime did not create title clusters or a content plan from seed queries alone.",
            "- Run approved XMLRiver `ai=1` collection or import AI citation title evidence before QFO content planning.",
            "",
        ])
    else:
        lines.extend([
            "- Each AI-cited page title is treated as a semantic unit.",
            "- The runtime only deduplicates exact repeated titles for evidence counting.",
            "- The agent or a clean subagent must read the full title list below before grouping titles into topics and building the final hub + child plan.",
            "- Do not use expanded query variants, n-gram masks, or template permutations as demand evidence.",
            "",
        ])
    lines.extend([
        "## Full AI-Cited Title Inventory",
        "",
        "| # | Source Query | Domain | Title | URL | Source |",
        "| ---: | --- | --- | --- | --- | --- |",
    ])
    for idx, row in enumerate(ai_titles, start=1):
        lines.append(f"| {idx} | {escape_md(row.get('source_query', ''))} | {escape_md(row.get('citation_domain', ''))} | {escape_md(row.get('base_title', ''))} | {escape_md(row.get('citation_url', ''))} | {escape_md(row.get('title_source', ''))} |")
    if not ai_titles:
        lines.append("| 0 | none | none | none | none | none |")
    lines.extend([
        "",
        "## Exact-Title Evidence Rows For Agent Clustering",
        "",
        "| Row | Title | AI Title Observations | Source Queries | Citation Domains | Status | Guard |",
        "| --- | --- | ---: | --- | --- | --- | --- |",
    ])
    for row in theme_rows:
        lines.append(
            f"| {escape_md(row.get('theme_id', ''))} | {escape_md(row.get('theme_label', ''))} | {row.get('title_semantic_count', 0)} | "
            f"{escape_md(row.get('source_seed_queries', ''))} | {escape_md(row.get('citation_domains', ''))} | {escape_md(row.get('content_plan_status', ''))} | {escape_md(row.get('cannibalization_guard', ''))} |"
        )
    if not theme_rows:
        lines.append("| none | none | 0 | none | none | none | none |")
    lines.extend([
        "",
        "## Content Plan Candidate Rows",
        "",
        "These rows are not a finished content plan. They are a workpack for agent/subagent logical clustering from the full title inventory.",
        "",
        "| Page | Type | Agent Task | Candidate Title | Included AI Titles | Status |",
        "| --- | --- | --- | --- | --- | --- |",
    ])
    for row in content_plan:
        lines.append(f"| {row.get('page_id', '')} | {row.get('page_type', '')} | {row.get('intent', '')} | {escape_md(row.get('target_title', ''))} | {escape_md(row.get('included_titles', ''))} | {row.get('status', '')} |")
    if not content_plan:
        lines.append("| none | none | none | none | none | none |")
    lines.extend(["", "## Artifacts", ""])
    for label, ref in paths.items():
        lines.append(f"- {label}: {ref}")
    lines.extend(["", "## Errors And Limits", ""])
    lines.extend([f"- {escape_md(error)}" for error in errors] or ["- none"])
    lines.extend([
        "",
        "## Next Valid Actions",
        "",
        "- Read the full AI title inventory and `data/processed/<topic>_qfo_title_semantics.csv`.",
        "- Cluster titles manually as the agent or send the full title inventory to a clean subagent; group only by user problem and page job.",
        "- Build the hub + child content plan from the approved logical QFO clusters, not from exact-title rows alone.",
        "- If available, provide ChatGPT QFO through `--chatgpt-qfo-file` as auxiliary context, not as a replacement for AI-cited titles.",
    ])
    return "\n".join(lines) + "\n"

def qfo_query_analysis(
    project_dir: Path,
    queries: str = "",
    queries_file: str = "",
    topic: str = "",
    engines: str = "google,yandex",
    region: str = "RU-Moscow",
    language: str = "ru",
    depth: int = 10,
    network_approved: bool = False,
    paid_approved: bool = False,
    timeout: int = 60,
    env_path: str = "",
    chatgpt_qfo_file: str = "",
    selected_themes: str = "",
) -> dict[str, Any]:
    topic = repair_text_encoding(topic)
    queries = repair_text_encoding(queries)
    engines = repair_text_encoding(engines)
    region = repair_text_encoding(region)
    language = repair_text_encoding(language)
    selected_themes = repair_text_encoding(selected_themes)
    root = find_project_root(project_dir)
    ensure_dirs(root)
    seed_rows = load_qfo_seed_queries(queries, queries_file)
    requested_top_urls, depth_errors = validate_serp_top_url_depth(depth, "xmlriver")
    depth = requested_top_urls
    topic_value = topic or (seed_rows[0]["query"] if seed_rows else "qfo-query-analysis")
    topic_slug = slugify(topic_value)
    chatgpt_rows = load_qfo_chatgpt_queries(chatgpt_qfo_file)
    engine_values = [engine for engine in split_csv(engines) if engine] or ["google", "yandex"]

    processed = root / PROCESSED_REL
    seed_path = processed / f"{topic_slug}_qfo_seed_queries.csv"
    chatgpt_path = processed / f"{topic_slug}_qfo_chatgpt_queries.csv"
    serp_path = processed / f"{topic_slug}_qfo_xmlriver_serp_rows.csv"
    ai_path = processed / f"{topic_slug}_qfo_xmlriver_ai_answers.csv"
    titles_path = processed / f"{topic_slug}_qfo_ai_titles.csv"
    title_semantics_path = processed / f"{topic_slug}_qfo_title_semantics.csv"
    themes_path = processed / f"{topic_slug}_qfo_theme_clusters.csv"
    plan_path = processed / f"{topic_slug}_qfo_content_plan.csv"
    summary_path = processed / f"{topic_slug}_qfo_analysis.json"
    selection_path = root / IMPORT_REL / f"{topic_slug}_qfo_theme_selection_template.csv"
    report_path = root / REPORTS_REL / "QFO_QUERY_ANALYSIS.md"
    chatgpt_request_path = root / REPORTS_REL / "QFO_CHATGPT_REQUEST.md"

    write_csv(seed_path, seed_rows)
    write_csv(chatgpt_path, chatgpt_rows)
    pages_per_pair = xmlriver_serp_page_count(depth)
    plan_rows = [
        {
            "request_id": f"qfo_request_{idx:04d}",
            "query_id": seed["query_id"],
            "query": seed["query"],
            "engine": engine,
            "include_ai": True,
            "provider": "xmlriver",
            "requested_top_urls": depth,
            "depth_semantics": "--depth is the requested organic URL count/top-N, not a pagination page count",
            "xmlriver_results_per_page": XMLRIVER_SERP_URLS_PER_PAGE,
            "xmlriver_serp_pages_per_query_engine": pages_per_pair,
            "planned_paid_requests": pages_per_pair,
            "xmlriver_max_threads": XMLRIVER_MAX_THREADS,
        }
        for idx, (seed, engine) in enumerate(((seed, engine) for seed in seed_rows for engine in engine_values), start=1)
    ]
    errors: list[str] = []
    errors.extend(depth_errors)
    serp_rows: list[dict[str, Any]] = []
    ai_rows: list[dict[str, Any]] = []
    ai_titles: list[dict[str, Any]] = []
    title_semantic_rows: list[dict[str, Any]] = []
    theme_rows: list[dict[str, Any]] = []
    content_plan: list[dict[str, Any]] = []
    selected_rows: list[dict[str, Any]] = []

    if not seed_rows:
        errors.append("No seed queries were provided. Use --queries or --queries-file.")
        write_text(chatgpt_request_path, build_qfo_chatgpt_request_report(topic_value, seed_rows, chatgpt_rows))
        paths = {"seed_queries": portable_ref(root, seed_path), "summary_json": portable_ref(root, summary_path)}
        write_text(report_path, build_qfo_query_analysis_report(topic_value, seed_rows, plan_rows, serp_rows, ai_rows, ai_titles, title_semantic_rows, theme_rows, content_plan, chatgpt_rows, errors, "invalid_args", paths))
        write_json(summary_path, {"status": "invalid_args", "topic": topic_value, "errors": errors, "generated_at": utc_now()})
        update_state(root, "qfo_query_analysis_invalid_args", [str(report_path), str(chatgpt_request_path), str(summary_path)])
        return observation("invalid_args", "QFO analysis requires seed queries.", evidence_refs=[str(report_path), str(chatgpt_request_path), str(summary_path)], next_valid_actions=["provide_queries"])

    unsupported_engines = [engine for engine in engine_values if engine not in XMLRIVER_ENDPOINTS]
    if unsupported_engines:
        errors.append(f"Unsupported XMLRiver engines: {', '.join(unsupported_engines)}")

    if not network_approved or not paid_approved or unsupported_engines or depth_errors:
        if not network_approved:
            errors.append("Live XMLRiver collection not run: --network-approved is missing.")
        if not paid_approved:
            errors.append("Live XMLRiver collection not run: --paid-approved is missing.")
        theme_rows, title_semantic_rows = qfo_cluster_queries([], [], seed_rows, chatgpt_rows)
        content_plan, selected_rows = qfo_build_content_plan(theme_rows, title_semantic_rows, selected_themes)
        write_csv(titles_path, ai_titles)
        write_csv(title_semantics_path, title_semantic_rows)
        write_csv(themes_path, theme_rows)
        write_csv(plan_path, content_plan)
        write_csv(selection_path, selected_rows)
        write_text(chatgpt_request_path, build_qfo_chatgpt_request_report(topic_value, seed_rows, chatgpt_rows))
        paths = {
            "seed_queries": portable_ref(root, seed_path),
            "chatgpt_queries": portable_ref(root, chatgpt_path),
            "title_semantics": portable_ref(root, title_semantics_path),
            "theme_clusters": portable_ref(root, themes_path),
            "content_plan": portable_ref(root, plan_path),
            "theme_selection_template": portable_ref(root, selection_path),
            "summary_json": portable_ref(root, summary_path),
        }
        write_text(report_path, build_qfo_query_analysis_report(topic_value, seed_rows, plan_rows, serp_rows, ai_rows, ai_titles, title_semantic_rows, theme_rows, content_plan, chatgpt_rows, errors, "blocked", paths))
        write_json(summary_path, qfo_summary_payload(
            "blocked",
            topic_value,
            seed_rows,
            chatgpt_rows,
            plan_rows,
            serp_rows,
            ai_rows,
            ai_titles,
            title_semantic_rows,
            theme_rows,
            content_plan,
            selected_rows,
            paths,
            errors,
            network_approved,
            paid_approved,
            engine_values,
            region,
            language,
            depth,
        ))
        update_state(root, "qfo_query_analysis_blocked", [str(report_path), str(chatgpt_request_path), str(summary_path)])
        return observation("blocked", "QFO XMLRiver analysis requires approved network and paid-provider scope.", items=[{"planned_query_engine_pairs": len(plan_rows), "planned_requests": xmlriver_paid_request_count(len(plan_rows), depth), "planned_paid_requests": xmlriver_paid_request_count(len(plan_rows), depth), "requested_top_urls": depth, "errors": len(errors)}], evidence_refs=[str(report_path), str(chatgpt_request_path), str(summary_path), str(selection_path)], next_valid_actions=["rerun_with_network_approved_and_paid_approved", "provide_chatgpt_qfo_optional"])

    env = load_env_values(root, env_path)
    accounts = xmlriver_accounts(env)
    if not accounts:
        errors.append("XMLRiver credentials not found in env. Required: XMLRIVER_USER and XMLRIVER_KEY or compatible aliases.")
        theme_rows, title_semantic_rows = qfo_cluster_queries([], [], seed_rows, chatgpt_rows)
        content_plan, selected_rows = qfo_build_content_plan(theme_rows, title_semantic_rows, selected_themes)
        write_csv(titles_path, ai_titles)
        write_csv(title_semantics_path, title_semantic_rows)
        write_csv(themes_path, theme_rows)
        write_csv(plan_path, content_plan)
        write_csv(selection_path, selected_rows)
        write_text(chatgpt_request_path, build_qfo_chatgpt_request_report(topic_value, seed_rows, chatgpt_rows))
        paths = {
            "seed_queries": portable_ref(root, seed_path),
            "chatgpt_queries": portable_ref(root, chatgpt_path),
            "title_semantics": portable_ref(root, title_semantics_path),
            "theme_clusters": portable_ref(root, themes_path),
            "content_plan": portable_ref(root, plan_path),
            "theme_selection_template": portable_ref(root, selection_path),
            "summary_json": portable_ref(root, summary_path),
        }
        write_text(report_path, build_qfo_query_analysis_report(topic_value, seed_rows, plan_rows, serp_rows, ai_rows, ai_titles, title_semantic_rows, theme_rows, content_plan, chatgpt_rows, errors, "blocked", paths))
        write_json(summary_path, qfo_summary_payload(
            "blocked",
            topic_value,
            seed_rows,
            chatgpt_rows,
            plan_rows,
            serp_rows,
            ai_rows,
            ai_titles,
            title_semantic_rows,
            theme_rows,
            content_plan,
            selected_rows,
            paths,
            errors,
            network_approved,
            paid_approved,
            engine_values,
            region,
            language,
            depth,
        ))
        update_state(root, "qfo_query_analysis_missing_xmlriver_credentials", [str(report_path), str(chatgpt_request_path), str(summary_path)])
        return observation("blocked", "XMLRiver credentials are required for QFO analysis.", evidence_refs=[str(report_path), str(chatgpt_request_path), str(summary_path), str(plan_path), str(selection_path)], next_valid_actions=["add_xmlriver_credentials", "manual_chatgpt_qfo_optional"])

    approval_path = record_qfo_xmlriver_approval(root, topic_value, topic_slug, engine_values, len(seed_rows), depth, region, language)
    run_id = f"qfo_xmlriver_{sha12(topic_value + utc_now())}"
    raw_dir = root / RAW_REL / "serp" / run_id
    try:
        collected = collect_xmlriver_plan_parallel(plan_rows, depth, region, language, True, accounts, raw_dir, timeout)
        serp_rows.extend(collected.get("serp_rows", []))
        ai_rows.extend(collected.get("ai_rows", []))
        errors.extend(collected.get("errors", []))
        thread_info = xmlriver_thread_scope(xmlriver_paid_request_count(len(plan_rows), depth))
        thread_info["xmlriver_thread_slots_used"] = collected.get("xmlriver_thread_slots_planned", thread_info.get("xmlriver_thread_slots_planned"))
    except Exception as exc:  # noqa: BLE001
        thread_info = xmlriver_thread_scope(xmlriver_paid_request_count(len(plan_rows), depth))
        errors.append(f"xmlriver_parallel_collection: {type(exc).__name__}: {exc}")

    ai_titles = extract_qfo_ai_titles(ai_rows, serp_rows)
    title_semantic_rows = qfo_title_semantic_units(ai_titles)
    theme_rows, title_semantic_rows = qfo_cluster_queries(title_semantic_rows, ai_titles, seed_rows, chatgpt_rows)
    content_plan, selected_rows = qfo_build_content_plan(theme_rows, title_semantic_rows, selected_themes)

    write_csv(serp_path, serp_rows)
    write_csv(ai_path, ai_rows)
    write_csv(titles_path, ai_titles)
    write_csv(title_semantics_path, title_semantic_rows)
    write_csv(themes_path, theme_rows)
    write_csv(plan_path, content_plan)
    write_csv(selection_path, selected_rows)
    write_text(chatgpt_request_path, build_qfo_chatgpt_request_report(topic_value, seed_rows, chatgpt_rows))

    collection_summary = {
        "run_id": run_id,
        "provider": "xmlriver",
        "workflow": "qfo_query_analysis",
        "topic": topic_value,
        "topic_slug": topic_slug,
        "network_approved": True,
        "paid_approved": True,
        "region": region,
        "language": language,
        "engines": engine_values,
        "depth": depth,
        "requested_top_urls": depth,
        "depth_semantics": "--depth is the requested organic URL count/top-N, not a pagination page count",
        "xmlriver_results_per_page": XMLRIVER_SERP_URLS_PER_PAGE,
        "xmlriver_serp_pages_per_query_engine": pages_per_pair,
        "planned_query_engine_pairs": len(plan_rows),
        "planned_requests": xmlriver_paid_request_count(len(plan_rows), depth),
        "planned_paid_requests": xmlriver_paid_request_count(len(plan_rows), depth),
        **thread_info,
        "seed_queries": len(seed_rows),
        "serp_rows": len(serp_rows),
        "ai_answer_rows": len(ai_rows),
        "ai_titles": len(ai_titles),
        "title_semantic_units": len(title_semantic_rows),
        "theme_clusters": len(theme_rows),
        "content_plan_rows": len(content_plan),
        "errors": errors,
        "generated_at": utc_now(),
    }
    write_json(raw_dir / "qfo_collection_summary.json", collection_summary)
    paths = {
        "seed_queries": portable_ref(root, seed_path),
        "chatgpt_queries": portable_ref(root, chatgpt_path),
        "xmlriver_serp_rows": portable_ref(root, serp_path),
        "xmlriver_ai_answers": portable_ref(root, ai_path),
        "ai_titles": portable_ref(root, titles_path),
        "title_semantics": portable_ref(root, title_semantics_path),
        "theme_clusters": portable_ref(root, themes_path),
        "content_plan": portable_ref(root, plan_path),
        "theme_selection_template": portable_ref(root, selection_path),
        "approval_ledger": portable_ref(root, approval_path),
        "raw_summary": portable_ref(root, raw_dir / "qfo_collection_summary.json"),
        "summary_json": portable_ref(root, summary_path),
    }
    status = "success" if ai_titles and not errors else ("quality_fail" if serp_rows or ai_rows else "error")
    if not ai_titles:
        errors.append("No AI-cited titles were extracted. The XMLRiver run completed or partially completed, but content planning is lower-assurance until a query returns AI sources.")
    write_text(report_path, build_qfo_query_analysis_report(topic_value, seed_rows, plan_rows, serp_rows, ai_rows, ai_titles, title_semantic_rows, theme_rows, content_plan, chatgpt_rows, errors, status, paths))
    write_json(summary_path, qfo_summary_payload(
        status,
        topic_value,
        seed_rows,
        chatgpt_rows,
        plan_rows,
        serp_rows,
        ai_rows,
        ai_titles,
        title_semantic_rows,
        theme_rows,
        content_plan,
        selected_rows,
        paths,
        errors,
        network_approved,
        paid_approved,
        engine_values,
        region,
        language,
        depth,
        extra={
            "run_id": run_id,
            "provider": "xmlriver",
            "workflow": "qfo_query_analysis",
            "collection_summary": collection_summary,
        },
    ))
    update_state(root, "qfo_query_analysis", [str(report_path), str(chatgpt_request_path), str(summary_path), str(plan_path)])
    return observation(
        status,
        "QFO XMLRiver analysis completed." if status == "success" else "QFO XMLRiver analysis completed with gaps.",
        items=[{"run_id": run_id, "planned_query_engine_pairs": len(plan_rows), "planned_requests": xmlriver_paid_request_count(len(plan_rows), depth), "planned_paid_requests": xmlriver_paid_request_count(len(plan_rows), depth), "requested_top_urls": depth, "serp_rows": len(serp_rows), "ai_answer_rows": len(ai_rows), "ai_titles": len(ai_titles), "title_semantic_units": len(title_semantic_rows), "theme_clusters": len(theme_rows), "content_plan_rows": len(content_plan), "errors": len(errors)}],
        evidence_refs=[str(report_path), str(chatgpt_request_path), str(summary_path), str(plan_path), str(raw_dir / "qfo_collection_summary.json")],
        next_valid_actions=["agent_logical_cluster_titles", "optionally_use_clean_subagent", "ask_user_to_filter_agent_clusters", "provide_chatgpt_qfo_optional"] if status == "success" else ["try_queries_with_ai_blocks", "review_errors", "provide_chatgpt_qfo_optional"],
    )
