# Install

Copy or unzip the runtime folder into the target project. The runtime is self-contained and uses Python standard library only for the base workflow.

## Quick Start

### Full First Run Path

Use this path for a new project. It deliberately separates environment adaptation, context, audit, and topic work.

```powershell
cd <target-project>
python -m geo_topic_agent.cli setup --runtime <codex|claude|cursor|opencode|antigravity|generic|cli|node> --apply-runtime-adaptation
python -m geo_topic_agent.cli collect-context --domain example.ru --brand Example --allow-site-discovery --network-approved --max-pages 30
python -m geo_topic_agent.cli audit-access --domain example.ru
python -m geo_topic_agent.cli llm-access-audit --url https://example.ru/target-page --network-approved --render
python -m geo_topic_agent.cli init-project --domain example.ru --brand Example --topic "cluster name" --cluster-queries-file cluster.txt
python -m geo_topic_agent.cli provider-audit
python -m geo_topic_agent.cli collect-serp --topic "cluster name" --cluster-queries-file cluster.txt --provider xmlriver --engines "google,yandex" --region "RU-Moscow" --language "ru" --dry-run
python -m geo_topic_agent.cli run-topic --topic "cluster name" --cluster-queries-file cluster.txt --domain example.ru --brand Example
python -m geo_topic_agent.cli generate-page-tz --topic "cluster name" --cluster-queries-file cluster.txt
python -m geo_topic_agent.cli citation-visibility --topic "cluster name" --domain example.ru --brand Example --queries-file cluster.txt --engines "google,yandex" --regions "RU-Moscow"
python -m geo_topic_agent.cli completion-audit --topic "cluster name"
python -m geo_topic_agent.cli final-evidence-audit --topic "cluster name"
```

### Fast Cluster Run

Use fast run only when environment setup, project/brand context, GEO/language/search-engine settings, and audit decision already exist. In this mode the only required new input is the cluster: topic/cluster name plus confirmed semantic queries.

```powershell
cd <target-project>
python -m geo_topic_agent.cli init-project --topic "cluster name" --cluster-queries-file cluster.txt
python -m geo_topic_agent.cli run-topic --topic "cluster name" --cluster-queries-file cluster.txt
python -m geo_topic_agent.cli generate-page-tz --topic "cluster name" --cluster-queries-file cluster.txt
python -m geo_topic_agent.cli monitor-plan --topic "cluster name"
```

Do not run paid/live providers from either path until the user approves exact engines, region, language, requested top URL count, query count, AI-block scope, XMLRiver 10-thread plan, and budget.

If the runtime is not on `PYTHONPATH`, run from the runtime directory or set:

```powershell
$env:PYTHONPATH="<path-to-runtime>"
```

## Target Adapters

The package includes native/import adapters:

- Codex: `AGENTS.md` plus `adapters/CODEX.md`
- Claude Code: `adapters/CLAUDE.md`
- Cursor Agent: `.cursor/rules/geo-topic-agent.mdc`
- OpenCode: `adapters/OPENCODE.md`
- Antigravity: `.antigravity/AGENTS.md` plus `adapters/ANTIGRAVITY.md`
- Generic agent runtimes: `AGENT.md` plus `adapters/GENERIC_AGENT.md`
- Python/local CLI: `adapters/PYTHON_MODULE.md`
- Node or mixed projects: `adapters/NODE_PROJECT.md` as a Python sidecar CLI pattern

Read `adapters/target-conformance.json` before claiming parity. On first run, use the active adapter setup command so `geo_agent/runtime/runtime-profile.json` and `geo_agent/runtime/birth-plan.json` are written before project context is collected.

## Optional Live Providers

Live XMLRiver, DataForSEO, Firecrawl, or other paid/network tools require explicit approval in the active agent environment and a durable approval ledger entry at `geo_agent/data/quality-gates/external_approval_ledger.json`. Store credentials in local `.env`; never commit or export them.

Use `env.example` as the minimal XMLRiver key-name template: `XMLRIVER_USER` and `XMLRIVER_KEY`. DataForSEO is supported but intentionally not included in `env.example`; when a DataForSEO run is requested, the agent must ask for approved credentials, scope, and budget before any live call. Run `collect-serp --dry-run` before any approved live call.

Before claiming a full live-proven 100% release, every item in `references/final-evidence-contract.json` must be `external_pass`. User-approved descopes produce only a limited `ready_with_descopes` claim. Use `references/final-evidence-runbook.md` for the approved command order, decision record, templates, and evidence artifacts. `setup` copies final-evidence templates to `geo_agent/data/import/final_evidence/`; these templates are preparation aids, not completed evidence.

## Post-Setup Cleanup

After installation and first successful setup:

- keep `AGENTS.md`, `geo-topic-contract.json`, `geo_topic_agent/`, `skills/`, `references/`, `templates/`, `schemas/`, `state/`, `memory/`, and the active adapter assets for the detected runtime;
- delete `FILES.sha256` only after archive verification if your import flow treats it as pre-install audit material;
- keep `.cursor/rules/geo-topic-agent.mdc` for Cursor installs, keep the matching `adapters/<target>.md` reference for the active runtime, and remove inactive adapters only after explicit approval or a retained-adapter reason is recorded;
- do not merge this router into a native instruction file or adapt skills into native mechanisms without user approval.

Optional: install Playwright in the target environment when rendered screenshots and rendered DOM text are required for llm-access-audit --render.

Page-level TZ generation uses skills/page-tz-generator/SKILL.md and python -m geo_topic_agent.cli generate-page-tz; competitor HTTP fetches require --network-approved, while local snapshots can be supplied through --competitor-content-dir.

Citation visibility tracking uses skills/citation-visibility-tracker/SKILL.md and python -m geo_topic_agent.cli citation-visibility; live provider collection requires --collect-live, --network-approved, and --paid-approved, while imported SERP/AI CSVs can be analyzed locally. History is append-only under data/visibility-runs/ and data/history/.

XMLRiver SERP collection must follow `references/xmlriver-serp-method.md`: choose explicit search engine, region, language, requested top URL count (`--depth`, not pagination pages), calculated paid page request count, XMLRiver max thread scope (`XMLRIVER_MAX_THREADS=10`), and AI scope; Google uses loc from https://xmlriver.com/files/geo.csv plus lr language, and Yandex uses numeric lr plus lang.
