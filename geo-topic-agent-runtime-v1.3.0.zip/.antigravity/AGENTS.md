# GEO Topic Agent - Antigravity Entrypoint

This is the Antigravity native entrypoint for the GEO Topic Agent.
Read the canonical router `../AGENTS.md` and obey it as the source of truth for user-facing work.

First-run command:

```powershell
python -m geo_topic_agent.cli setup --runtime antigravity --apply-runtime-adaptation
```

The operating path is strict: adapt to environment first, then collect project/brand context, offer and run/decline site plus target-page audit, then request topic + confirmed semantic cluster, then build content plan, page TZ, and monitoring.

Fast run is cluster-only and relies on saved project context. Never invent missing semantics; draft them only for user approval.
