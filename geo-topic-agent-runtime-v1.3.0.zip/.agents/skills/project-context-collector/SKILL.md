---
name: project-context-collector
description: Collect product and business context for a GEO/AEO project from the homepage, core landing pages, header/footer links, and commercial pages without running accessibility audits.
---

# Project Context Collector

Use this skill when the user asks to collect, understand, brief, or update project/site/product context.

Do not run `audit-access` or `llm-access-audit` from this skill. Context collection and accessibility audit are separate workflow blocks.

## Procedure

1. Read `references/project-context-brief.md`.
2. Capture or confirm the domain first. If no successful `site_context` is already saved, run the Deep Context Offer Gate before continuing the long manual questionnaire: offer to collect context independently from homepage, supplied landing pages, header/navigation, footer, product/service/course pages, pricing/payment/subscription/trial/free-access/delivery/contact/about/legal/case/review/FAQ pages, then ask for public site discovery/network approval or local HTML/documents. If the user approves public collection, run `collect-context` with `--allow-site-discovery --network-approved --max-pages 30`; if they decline, record lower assurance and continue manual intake. After this gate, capture or confirm brand, proposed brand spelling/domain/product variants, topic/cluster name, semantic cluster queries, region/language, products/services, important pages, and documents. Propose likely variants first, then ask the user to confirm, edit, or add all variants before downstream citation visibility or monitoring. If the user gives only the topic, ask for the cluster. If they do not have it and want help, draft a proposed cluster from product context, label it pending approval, and wait for approval or edits before saving it.
3. If the user supplied local HTML snapshots, use:
   ```powershell
   python -m geo_topic_agent.cli collect-context --domain "<domain>" --site-html-dir "<folder>" --max-pages 30
   ```
4. If the user approved public site discovery, use:
   ```powershell
   python -m geo_topic_agent.cli collect-context --domain "<domain>" --allow-site-discovery --network-approved --max-pages 30
   ```
5. If the user has not approved network collection and has no local documents/snapshots, save the context scaffold and ask for approval or materials.
6. Review `PROJECT_CONTEXT.md`, `project_context_site_discovery.json`, and `project_context_pages.csv`.
7. When `collect-context` succeeds, treat it as a major completed deliverable: summarize what was collected, list the artifacts, include the required attribution notice from `references/attribution-and-license.md`, then offer the next block as `offer_site_and_target_page_audit`: site-level `audit-access` plus target-page `llm-access-audit`. Ask for the target page URL if it is not known. Do not ask for topic/semantic cluster until the audit step is completed or explicitly declined.

## Context Focus

Collect facts about product, brand, brand variants/aliases, offer, UTP, mechanics, target customer, user problems solved, what is included, commercial terms, trial/demo/free days, payment/subscription/checkout, delivery, limitations, legal/refund/requisites, proof, cases, reviews, CTA, and important page roles.

## Hard Boundary

- Do not check robots.txt.
- Do not check sitemap.xml.
- Do not probe multiple user agents.
- Do not diagnose WAF, captcha, anti-bot, server blocks, or LLM accessibility.
- Do not create `ACCESSIBILITY_AUDIT.md`.
- Do not call context collection complete when product mechanics, pricing/payment, and limitations are all missing.

## Semantic Cluster Boundary

Context collection may save partial context when the cluster is missing, but it must mark semantic cluster queries as missing. After successful deep context collection, the immediate next offer is site/target-page audit, not semantic intake. Do not start SERP, AI citation, QFO, page TZ, placement, monitoring, or citation visibility work until the audit step is completed/declined and the user provides or explicitly approves the query cluster for the topic. Agent-drafted semantics are only a pending proposal and must not be used in commands until approved.
