---
name: qfo-query-analysis
description: Analyze a user-provided QFO/query fan-out batch with approved XMLRiver SERP+AI collection, AI-cited title extraction, title semantics inventory, agent/subagent logical clustering, cannibalization-safe hub/child planning, optional ChatGPT QFO import, and content plan creation.
---

# QFO Query Analysis

Use this skill when the user provides a batch of search queries and wants all possible QFO directions, grouped themes, and a content plan.

QFO means Query Fan-Out: the set of follow-up, adjacent, implied, and reformulated searches that AI/search systems may create around the user's seed queries. The goal is to see which questions and page topics the market repeatedly exposes through SERP and AI-answer citation evidence, then turn that evidence into a cannibalization-safe hub + child content structure.

## Required Inputs

- User-provided seed queries as `--queries` or `--queries-file`.
- Approved paid XMLRiver live collection before any real SERP/API request: `--network-approved --paid-approved`.
- Region, language, engines, requested top URL count (`--depth`, not pagination pages), paid XMLRiver page request count, and XMLRiver max thread scope (`XMLRIVER_MAX_THREADS=10`). `qfo-analyze` defaults to `google,yandex`; use a narrower `--engines` value only when the user explicitly scopes it. Read `references/xmlriver-serp-method.md`; use `https://xmlriver.com/files/geo.csv` for Google `loc` and numeric Yandex `lr` for Yandex.
- Optional ChatGPT QFO export from the user through `--chatgpt-qfo-file`. The user may skip it.

## Workflow

1. Parse every user-provided seed query into an ordered input inventory.
2. Run XMLRiver SERP collection for every seed query and selected engine with `ai=1`, explicit `--region`, explicit `--language`, explicit top-N URL count, calculated paid page request count, `XMLRIVER_MAX_THREADS=10`, and engine-specific XMLRiver parameters from `references/xmlriver-serp-method.md`.
3. Save raw XML, parsed organic SERP rows, parsed AI answer/source rows, and collection summary.
4. Extract page titles from AI answer citations using the full XMLRiver AI parser: XMLRiver source nodes, `citation_url`, `cited_urls`, and links embedded in `answer_text` HTML. When a browser/manual AI snapshot is used, expand all AI/source/citation blocks and save the expanded snapshot before opening any cited URL. When the AI source row has a URL but no title, match the URL against organic rows from the same live run. Never treat XMLRiver error payloads as citation evidence.
5. Treat every AI-cited page title as a semantic unit. Do not expand titles into template queries, n-gram masks, or deterministic intent permutations.
6. Ask the user to provide ChatGPT QFO output, but do not block if it is missing. ChatGPT QFO is auxiliary context, not a replacement for AI-cited titles.
7. Read the full AI title inventory, then cluster titles logically by user problem and page job. Use a clean subagent when available; otherwise the agent must do the reasoning itself.
8. Propose hub + child structure only after reading all titles, with a cannibalization guard for each logical cluster.
9. Write a theme stats table showing how often exact AI-cited title evidence appeared and which source queries produced it.
10. Let the user filter agent-created logical clusters. If no selected clusters are provided, keep the plan in `pending_agent_logical_plan` state.
11. Write the final QFO content plan from approved logical clusters, not from exact-title rows alone.

## Outputs

- `reports/QFO_QUERY_ANALYSIS.md`
- `reports/QFO_CHATGPT_REQUEST.md`
- `data/processed/<topic>_qfo_seed_queries.csv`
- `data/processed/<topic>_qfo_xmlriver_serp_rows.csv`
- `data/processed/<topic>_qfo_xmlriver_ai_answers.csv`
- `data/processed/<topic>_qfo_ai_titles.csv`
- `data/processed/<topic>_qfo_title_semantics.csv`
- `data/processed/<topic>_qfo_theme_clusters.csv`
- `data/processed/<topic>_qfo_content_plan.csv`
- `data/processed/<topic>_qfo_analysis.json`
- `data/import/<topic>_qfo_theme_selection_template.csv`

## User-Facing Result

The user should see:

- which seed queries were actually collected;
- where AI answers existed and which pages/titles AI cited;
- the full list of AI-cited titles and title semantic units;
- which exact titles repeat and which logical clusters the agent/subagent created from the full title list;
- which pages should be hubs and which should be child pages;
- where cannibalization risk exists;
- what remains pending because ChatGPT QFO was not supplied or because the user has not filtered themes.

Never claim that ChatGPT, Google AI Overview, Yandex, or another AI/search system will cite a page. This skill produces evidence-backed planning artifacts only.
