---
name: page-tz-generator
description: Generate a clean standalone copywriter-facing semantic SEO/GEO technical specification from a user topic using previously parsed AI citation competitors, deterministic competitor content extraction, parsing quality checks, balanced n-gram analysis with median density targets, QFO title-semantics coverage plus confirmed cluster queries, and required AI-citation chunks. Use when the user asks to generate a TZ, content brief, page specification, or SEO/GEO task for one page.
---

# Page TZ Generator

Use this skill when the user asks for a generated TZ under one page/topic, not only a handoff to an external generator.

## Workflow

1. Read `references/page-tz-generator-method.md`.
2. Read `references/tool-registry.json` and use the `page_tz_generator` tool.
3. Run:

   ```powershell
   python -m geo_topic_agent.cli generate-page-tz --topic "<topic/cluster>" --cluster-queries "<query 1>; <query 2>"
   ```

4. The deterministic tool must select competitors from previously parsed AI citations when available:
   - `*_qfo_ai_titles.csv`
   - `*_qfo_xmlriver_ai_answers.csv`
   - `*_live_ai_answers.csv`
   - `*_ai_answers.csv`
5. The tool must extract competitor content, run parsing quality checks, run balanced 1/2/3-gram analysis, preserve a larger bigram layer, calculate median competitor density targets, and write the TZ artifacts.
6. If HTTP extraction is needed, use `--network-approved`. If HTTP fails or content quality is weak, use a browser/agent collection path if the host runtime provides one, save the collected content as local HTML/TXT, and rerun with `--competitor-content-dir`.
7. After the deterministic tool runs, inspect `PAGE_TZ.md` as a standalone brief for a copywriter agent with no chat context. Keep parser statuses, raw refs, editor QA notes, UI labels, and internal tool comments out of `PAGE_TZ.md`; weak parsing and technical notes belong in `PAGE_TZ_GENERATION.md`.

## Outputs

- `reports/PAGE_TZ.md`
- `reports/PAGE_TZ_GENERATION.md`
- `data/processed/<topic>_page_tz.json`
- `data/processed/<topic>_tz_competitors.csv`
- `data/processed/<topic>_tz_content_quality.csv`
- `data/processed/<topic>_tz_ngrams.csv`
- `data/processed/<topic>_tz_chunks.csv`

## Rules

- Do not call a handoff a generated TZ.
- Do not invent competitor content. If content was not parsed, mark the competitor as blocked or weak.
- Do not create a TZ from only model reasoning when QFO or AI-citation evidence exists locally.
- Do not hide parse failures. Parsing quality is part of the deliverable.
- The final TZ must include page structure, QFO title-semantics coverage, confirmed cluster query coverage, competitor evidence, n-gram terms with median density recommendations, and required chunks aimed at being clear, extractable, and citeable by AI systems.
- The final `PAGE_TZ.md` is for a copywriter or copywriter agent only. It must not contain personal notes, parser statuses, raw refs, service labels such as `commercial child queries`, UI text such as `open in new tab`, or instructions that only make sense inside the current chat.
