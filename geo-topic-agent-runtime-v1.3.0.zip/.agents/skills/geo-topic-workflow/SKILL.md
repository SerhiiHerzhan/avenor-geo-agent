---
name: geo-topic-workflow
description: Run the one-topic GEO/AEO workflow from environment setup through accessibility, provider audit, fan-out/QFO, SERP/AI analysis, content plan, placements, enrichment, monitoring, and completion audit.
---

# GEO Topic Workflow

Use this skill when the user asks to run a GEO/AEO agent for one site, one topic, one content cluster, or one page opportunity.

## Topic + Cluster Contract

The workflow works on `topic + semantic cluster`. Ask for a topic/cluster name and the user query cluster before SERP, AI citation, topic run, page TZ, placement, monitoring, or visibility work. The topic is only the cluster/page label; every SERP/AI/QFO/TZ step uses confirmed user-supplied or user-approved cluster queries by default. If the user gives only a topic, ask for the cluster first. If the user has no cluster and asks the agent to prepare one, draft it from product context as `DRAFT semantic cluster - pending user approval`, then wait for explicit approval before saving or using it.

## Workflow

1. Run or verify setup:
   ```powershell
   python -m geo_topic_agent.cli setup --runtime <active-runtime> --apply-runtime-adaptation
   ```
2. Capture manual project fields one question at a time. Ask for site/domain, brand, proposed brand variants/aliases, products/services, topic, region/language, search engines, pages, competitors, documents, and whether public site discovery is approved. Propose likely variants first and ask the user to confirm/edit/add all variants:
   ```powershell
   python -m geo_topic_agent.cli init-project --domain <domain> --brand <brand> --brand-variants "<brand; brand spelling; domain; product alias>" --topic "<topic/cluster>" --cluster-queries "<query 1>; <query 2>"
   ```
3. Collect product/site context as a separate block. Read `skills/project-context-collector/SKILL.md`; study homepage, main landing pages, header/footer links, and commercial pages. Do not run accessibility audit here:
   ```powershell
   python -m geo_topic_agent.cli collect-context --domain <domain> --allow-site-discovery --network-approved --max-pages 30
   ```
4. Audit accessibility only as an explicit next block after context collection:
   ```powershell
   python -m geo_topic_agent.cli audit-access --domain <domain>
   ```
5. Audit provider readiness and plan SERP collection:
   ```powershell
   python -m geo_topic_agent.cli provider-audit
   python -m geo_topic_agent.cli collect-serp --topic "<topic/cluster>" --cluster-queries "<query 1>; <query 2>" --dry-run
   ```
6. Run topic:
   ```powershell
   python -m geo_topic_agent.cli run-topic --topic "<topic/cluster>" --cluster-queries "<query 1>; <query 2>" --domain <domain> --brand <brand> --brand-variants "<confirmed variants>"
   ```
7. Build product-fit external placement ideas for a concrete cluster when the user asks for placements, seeding, outreach targets, or brand/product seeding opportunities:
   ```powershell
   python -m geo_topic_agent.cli find-placements --topic "<cluster>" --queries "<query 1>; <query 2>" --product "<product/service>" --target-action "<conversion/action>" --geo "<region>" --language "<language>" --max-ideas 30
   ```
8. Optional approved live data and URL enrichment:
   ```powershell
   python -m geo_topic_agent.cli collect-serp --topic "<topic/cluster>" --cluster-queries "<query 1>; <query 2>" --network-approved --include-ai
   python -m geo_topic_agent.cli collect-serp --topic "<topic/cluster>" --cluster-queries "<query 1>; <query 2>" --provider dataforseo --engines google --network-approved --include-ai
   python -m geo_topic_agent.cli enrich-urls --topic "<topic>" --network-approved
   ```
9. Optional approved semantic TZ generator invocation:
   ```powershell
   python -m geo_topic_agent.cli invoke-tz-generator --topic "<topic>" --generator-command "<cmd with {handoff} and {output_dir}>" --invoke-approved
   ```
10. Run completion audit and disclose lower-assurance items:
   ```powershell
   python -m geo_topic_agent.cli completion-audit --topic "<topic>"
   python -m geo_topic_agent.cli final-evidence-audit --topic "<topic>"
   python -m geo_topic_agent.cli final-evidence-readiness --topic "<topic>"
   python -m geo_topic_agent.cli independent-audit-pack --topic "<topic>"
   python -m geo_topic_agent.cli record-descope --evidence-id <id> --approved-by "<user>" --reason "<reason>"
   ```

## Evidence Rules

- If live SERP is not approved, create manual import templates and continue with fan-out and planning.
- If AI answers are disabled or missing, state it clearly and continue SERP/fan-out analysis.
- If only a topic is supplied without semantic cluster queries, block SERP/AI/topic-run/TZ/placement/monitoring work and ask for the cluster. Do not use the topic name as the query list. Do not invent a query count or provider scope. If the user asks the agent to draft semantics, label the draft as pending user approval and wait; only an approved or edited cluster can be passed to `--cluster-queries`.
- Context collection must never create `ACCESSIBILITY_AUDIT.md`; `audit-access` is a separate explicit block.
- Project context must preserve product facts: UTP, offer mechanics, target customer, CTA, pricing/payment/trial/delivery, limitations, proof, and important page roles.
- If provider data is imported or collected, preserve row-level CSV/JSON evidence and raw provider references. For browser/manual AI evidence, expand every AI/source/citation block and save expanded HTML/screenshot before opening any cited URL; early citation clicks are invalid because they can lose hidden sources.
- Do not collapse retrieval, URL citation source, and answer-body brand mention into one score. Monitoring must expose `url_citation` and `brand_mention` as separate layers.
- For external placements, use `skills/product-placement-opportunities/SKILL.md`: generate `enter_existing` and `create_owned` ideas only where the user problem naturally leads to the product.

## Required Outputs

- `ADAPTATION_REPORT.md`
- `PROJECT_CONTEXT.md`
- `ACCESSIBILITY_AUDIT.md`
- `PROVIDER_AUDIT.md`
- `SERP_COLLECTION.md`
- `FANOUT_MAP.md`
- `SERP_AI_ANALYSIS.md`
- `CONTENT_PLAN.md`
- `TZ_HANDOFF_REPORT.md`
- `TZ_GENERATOR_INVOCATION.md` when generator invocation is approved
- `PLACEMENT_STRATEGY.md`
- `MONITORING_PLAN.md`
- `COMPLETION_AUDIT.md`
- `FINAL_EVIDENCE_AUDIT.md`

## Quality Gate

Before final response, confirm:

- every required report exists;
- skipped tools are listed;
- assumptions are visible;
- handoff JSON exists;
- no API keys appear in outputs;
- SQLite storage exists after `run-topic`;
- provider/live collection warnings are visible;
- final evidence audit separates external_pass from external_pending;
- next action is explicit.
