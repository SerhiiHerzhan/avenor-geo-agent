# STATE

Last action: no project state yet.

Current work: waiting for GEO/AEO project intake.

Blockers: none.

Next valid action: ask for the site/domain or run `python -m geo_topic_agent.cli setup`.

Evidence refs: none.